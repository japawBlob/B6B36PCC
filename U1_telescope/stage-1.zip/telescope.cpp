#include "telescope.hpp"
#include <sstream>
#include <iomanip>
#include <stdexcept>

// --------------------- STAGE 1 ---------------------
std::pair<size_t, size_t> parse_matrix(std::istream& in){
    std::string line;
    size_t numberOfRows = 0;
    size_t numberOfColumns = 0;
    while (std::getline(in, line)){
        int element;
        std::istringstream lineStream(line);
        size_t temp_counter = 0;
        while ( lineStream >> element ) {
            temp_counter++;
        }
        if (numberOfColumns == 0) {
            numberOfColumns = temp_counter;
        }
        if (temp_counter != numberOfColumns) {
            throw std::invalid_argument( "Number of columns is not consistent across rows" );
        }
        numberOfRows++;
    }
    return std::make_pair (numberOfRows, numberOfColumns);
}

std::vector<int> parse_matrix(std::istream& in, const std::pair<size_t, size_t>& m_size){
    std::string line;
    std::vector<int> matrix;
    size_t numberOfRows = 0;
    size_t numberOfColumns = 0;
    while (std::getline(in, line)){
        int element;
        std::istringstream lineStream(line);
        size_t temp_counter = 0;
        while ( lineStream >> element ) {
            temp_counter++;
            matrix.push_back(element);
        }
        if (numberOfColumns == 0) {
            numberOfColumns = temp_counter;
        }
        if (temp_counter != numberOfColumns) {
            throw std::invalid_argument( "Number of columns is not consistent across rows" );
        }
        numberOfRows++;
    }
    return matrix;
}

size_t get_widest_element (const std::vector<int> & vec){
    size_t max_width = 0;
    for (auto & element : vec){
        std::string s = std::to_string(element);
        if (s.size() > max_width) {
            max_width = s.size();
        }
    }
    return max_width;
}

void print_matrix(std::ostream& out, const std::pair<size_t, size_t>& m_size, const std::vector<int>& vec){
    size_t numberOfRows = m_size.first;
    size_t numberOfColumns = m_size.second;

    if (numberOfColumns == 0 || numberOfRows == 0){
        return;
    }
    
    size_t max_width = get_widest_element(vec);
    for ( size_t i = 0; i < numberOfColumns*(max_width+3) + 1; i++){
        out << "-";
    }
    out << std::endl; 
    for ( size_t i = 0; i < numberOfRows; i++){
        for ( size_t  j = 0; j < numberOfColumns; j++){
            out << "| " << std::setw(max_width) << vec[i*numberOfColumns+j] << " ";
        }
        out << "|" << std::endl;
    }
    for ( size_t i = 0; i < numberOfColumns*(max_width+3) + 1; i++){
        out << "-";
    }
    out << std::endl; 
}

// --------------------- STAGE 2 ---------------------

std::vector<unsigned char> parse_stream(std::istream& in, const std::pair<size_t, size_t>& m_size){
    std::vector<unsigned char> blob;
    return blob;
}

void rotate_down(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec){

}

void rotate_down(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec, int step){

}

void rotate_right(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec){

}

void rotate_right(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec, int step){

}

void swap_points(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec, const Point& p1, const Point& p2){

}

void swap_points(const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec, const Point& p1, const Point& p2, const Point& delta){

}

// --------------------- STAGE 3 ---------------------

void decode_picture(const std::string& file, const std::pair<size_t, size_t>& m_size, std::vector<unsigned char>& vec){

}
